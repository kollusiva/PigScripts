use krypton;
select call_variable_value,event_code,country_id from events_raw limit 10;
add FILE /idn/home/kryptons/scripts/GetMyDate.py;

CREATE EXTERNAL TABLE IF NOT EXISTS events_1
(geotelid string,
event_code string,
country_id string)
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t';

INSERT OVERWRITE TABLE events_1
SELECT
  TRANSFORM (trim(call_variable_value),event_code,country_id)
  USING 'python GetMyDate.py'
  AS (geotelid,event_code,country_id)
FROM events_raw
where trim(call_variable_value) <> ''
limit 100;

select call_variable_value, event_code, country_id
from events_raw limit 100;

INSERT OVERWRITE TABLE events_1
FIELDS TERMINATED BY  '\t' 
ESCAPED BY '"' 
LINES TERMINATED BY '\n'
SELECT
  TRANSFORM (trim(call_variable_value),event_code,country_id)
  USING 'python GetMyDate.py'
  AS (geotelid,event_code,country_id)
FROM events_raw
where trim(call_variable_value) <> '' and trim(event_code) <> '' and trim(country_id) <> ''
limit 100;

INSERT OVERWRITE DIRECTORY '/axp/ws/krypton/dev/database/events_1/'
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY  '\t' 
LINES TERMINATED BY '\n' 
STORED AS TEXTFILE
SELECT
  trim(call_variable_value),event_code,country_id
FROM events_raw
where trim(call_variable_value) <> '' and trim(event_code) <> '' and trim(country_id) <> ''
limit 100;