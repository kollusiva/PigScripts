# rmdir /axp/gcp/gcpmark/dev/skoll9/output

hadoop jar /opt/mapr/hadoop/hadoop-0.20.2/contrib/streaming/hadoop-*streaming*.jar \
		-mapper /axp/gcp/gcpmark/dev/skoll9/mapper.py \
		-file /axp/gcp/gcpmark/dev/skoll9/mapper.py \
		-reducer /axp/gcp/gcpmark/dev/skoll9/reducer.py \
        -file /axp/gcp/gcpmark/dev/skoll9/reducer.py \
		-input /axp/gcp/gcpmark/dev/skoll9/error.txt \
		-output /axp/gcp/gcpmark/dev/skoll9/output
		

#run in localmode
cat /axp/gcp/gcpmark/dev/skoll9/lincoln.txt | /axp/gcp/gcpmark/dev/skoll9/mapper.py | sort | /axp/gcp/gcpmark/dev/skoll9/reducer.py >> results.txt


hadoop jar /opt/mapr/hadoop/hadoop-0.20.2/contrib/streaming/hadoop-*streaming*.jar  \
		-D mapred.reduce.tasks=0 \
		-mapper 'python /axp/gcp/gcpmark/dev/skoll9/mapper.py' \
		-file /axp/gcp/gcpmark/dev/skoll9/mapper.py \
		-input /axp/gcp/gcpmark/dev/skoll9/error.txt \
		-output /axp/gcp/gcpmark/dev/skoll9/output 
		